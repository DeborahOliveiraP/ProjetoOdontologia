package application;

public class Program {

}
