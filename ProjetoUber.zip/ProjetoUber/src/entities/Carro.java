package entities;

public class Carro {

	public String uberComfort;
	public String uberX;
	public String uberBlack;
	
	
	public String getUberComfort() {
		
		return uberComfort;
	}
	public void setUberComfort(String uberComfort) {
		this.uberComfort = uberComfort;
	}
	public String getUberX() {
		return uberX;
	}
	public void setUberX(String uberX) {
		this.uberX = uberX;
	}
	public String getUberBlack() {
		return uberBlack;
	}
	public void setUberBlack(String uberBlack) {
		this.uberBlack = uberBlack;
	}
	
	
	
}

