package entities;

public class Passageiro extends Usuario {

}
