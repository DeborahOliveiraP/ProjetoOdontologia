package entities;

public class Motorista extends Usuario {
	
	
}
