package entities;

public class Pagamento {

	private double cartao;
	private double dinheiro;
	private double pix;
	
	
	
}
